// DOM Elements
const textElement = document.getElementById("text");
const optionButtonsElement = document.getElementById("option-buttons");

// Binary Tree Classes (unchanged)
class Node {
  constructor(data) {
    this.data = data;
    this.left = null;
    this.right = null;
  }
}

class BinaryTree {
  constructor() {
    this.root = null;
  }

  insert(data) {
    this.root = this._insertRecursive(this.root, data);
  }

  _insertRecursive(node, data) {
    if (!node) return new Node(data);
    if (data < node.data) node.left = this._insertRecursive(node.left, data);
    else node.right = this._insertRecursive(node.right, data);
    return node;
  }

  inorderTraversal(node, result = []) {
    if (node) {
      this.inorderTraversal(node.left, result);
      result.push(node.data);
      this.inorderTraversal(node.right, result);
    }
    return result;
  }

  preorderTraversal(node, result = []) {
    if (node) {
      result.push(node.data);
      this.preorderTraversal(node.left, result);
      this.preorderTraversal(node.right, result);
    }
    return result;
  }

  postorderTraversal(node, result = []) {
    if (node) {
      this.postorderTraversal(node.left, result);
      this.postorderTraversal(node.right, result);
      result.push(node.data);
    }
    return result;
  }

  deleteNode(node, key) {
    if (!node) return null;
    if (key < node.data) node.left = this.deleteNode(node.left, key);
    else if (key > node.data) node.right = this.deleteNode(node.right, key);
    else {
      if (!node.left) return node.right;
      if (!node.right) return node.left;

      let minLargerNode = this._findMin(node.right);
      node.data = minLargerNode.data;
      node.right = this.deleteNode(node.right, minLargerNode.data);
    }
    return node;
  }

  _findMin(node) {
    while (node.left) node = node.left;
    return node;
  }
}

// Heap Class (unchanged)
class Heap {
  constructor() {
    this.heap = [];
  }

  insertHeap(value) {
    this.heap.push(value);
    this._heapifyUp(this.heap.length - 1);
  }

  _heapifyUp(index) {
    while (index > 0 && this.heap[this._parent(index)] < this.heap[index]) {
      [this.heap[index], this.heap[this._parent(index)]] = 
        [this.heap[this._parent(index)], this.heap[index]];
      index = this._parent(index);
    }
  }

  _parent(index) {
    return Math.floor((index - 1) / 2);
  }

  buildMinHeap() {
    for (let i = Math.floor(this.heap.length / 2) - 1; i >= 0; i--) {
      this._minHeapify(i);
    }
  }

  _minHeapify(index) {
    let smallest = index;
    let left = 2 * index + 1;
    let right = 2 * index + 2;

    if (left < this.heap.length && this.heap[left] < this.heap[smallest]) {
      smallest = left;
    }
    if (right < this.heap.length && this.heap[right] < this.heap[smallest]) {
      smallest = right;
    }
    if (smallest !== index) {
      [this.heap[index], this.heap[smallest]] = [this.heap[smallest], this.heap[index]];
      this._minHeapify(smallest);
    }
  }

  buildMaxHeap() {
    for (let i = Math.floor(this.heap.length / 2) - 1; i >= 0; i--) {
      this._maxHeapify(i);
    }
  }

  _maxHeapify(index) {
    let largest = index;
    let left = 2 * index + 1;
    let right = 2 * index + 2;

    if (left < this.heap.length && this.heap[left] > this.heap[largest]) {
      largest = left;
    }
    if (right < this.heap.length && this.heap[right] > this.heap[largest]) {
      largest = right;
    }
    if (largest !== index) {
      [this.heap[index], this.heap[largest]] = [this.heap[largest], this.heap[index]];
      this._maxHeapify(largest);
    }
  }
}

// Initialize Binary Tree and Heap
let bt = new BinaryTree();
let heap = new Heap();

const initialNumbers = [5, 3, 2, 4, 7, 6, 8];
initialNumbers.forEach(num => bt.insert(num));

let displayedNumbers = [...initialNumbers]; // Preserve original numbers for display

// Heap-Specific Display Function
function displayHeap() {
  return `Current heap state: ${heap.heap.join(", ")}`;
}

// Rooms for Binary Tree Questions (1-11)
const binaryTreeRooms = [
  {
    id: 1,
    text: "What is the inorder traversal of the binary tree?",
    options: [
      [2, 3, 4, 6, 7, 8],
      [2, 3, 5, 6, 7, 8],
      [2, 3, 4, 5, 7, 8],
      [2, 3, 4, 5, 6, 7, 8]
    ],
    answer: [2, 3, 4, 5, 6, 7, 8],
    process: () => {},
    hint: "Visit left subtree, root, and right subtree.",
  },
  {
    id: 2,
    text: "After deleting 4, what is the new inorder traversal?",
    options: [
      [2, 3, 5, 4, 6, 7, 8],
      [2, 3, 5, 6, 7, 8],
      [2, 5, 6, 7, 8],
      [2, 3, 5, 6, 8]
    ],
    answer: [2, 3, 5, 6, 7, 8],
    process: () => {
      bt.root = bt.deleteNode(bt.root, 4);
      displayedNumbers = bt.inorderTraversal(bt.root);
    },
    hint: "After deleting a node, the tree reorganizes itself.",
  },
  {
    id: 3,
    text: "After inserting 10, what is the new inorder traversal?",
    options: [
      [2, 3, 5, 6, 7, 4, 10],
      [2, 3, 4, 5, 6, 7, 8, 10],
      [2, 3, 5, 6, 7, 8, 10],
      [2, 3, 5, 6, 7, 10, 8]
    ],
    answer: [2, 3, 5, 6, 7, 8, 10],
    process: () => {
      bt.insert(10);
      displayedNumbers = bt.inorderTraversal(bt.root);
    },
    hint: "New elements are inserted into the tree.",
  },
  {
    id: 4,
    text: "Enter the Preorder traversal of the binary tree.",
    options: [
      [5, 4, 2, 6, 7, 8, 10],
      [5, 3, 2, 4, 7, 8, 10],
      [5, 6, 7, 8, 2, 3, 10],
      [5, 3, 2, 6, 7, 8, 10]
    ],
    answer: [5, 3, 2, 6, 7, 8, 10],
    process: () => {},
    hint: "Preorder traversal: Visit root, left subtree, right subtree.",
  },
  {
    id: 5,
    text: "Enter the Postorder traversal of the binary tree.",
    options: [
      [2, 3, 6, 8, 10, 7, 5],
      [2, 4, 3, 7, 8, 10, 5],
      [2, 3, 6, 8, 7, 5],
      [2, 3, 6, 10, 7, 8, 5]
    ],
    answer: [2, 3, 6, 8, 10, 7, 5],
    process: () => {},
    hint: "Postorder traversal: Visit left subtree, right subtree, root.",
  },
  {
    id: 6,
    text: "Is the value 6 present in the binary tree?",
    options: [
      ["No"],
      ["Yes"],
      ["Maybe"],
      ["I don't know"]
    ],
    answer: ["Yes"],
    process: () => {},
    hint: "Look for the value 6 in the binary tree.",
  },

  {
    id: 7,
    text: "What is the inorder traversal of the binary search tree after inserting 9?",
    options: [
      [2, 3, 5, 6, 7, 8, 9, 10],
      [2, 3, 5, 6, 7, 9, 8, 10],
      [2, 3, 5, 6, 7, 8, 10],
      [2, 3, 5, 6, 9, 7, 8, 10]
    ],
    answer: [2, 3, 5, 6, 7, 8, 9, 10],
    process: () => {
      bt.insert(9);
      displayedNumbers = bt.inorderTraversal(bt.root);
    },
    hint: "BST insertion places elements correctly based on value.",
  },
  {
    id: 8,
    text: "What is the preorder traversal of the binary search tree?",
    options: [
      [5, 4, 2, 6, 7, 8, 9, 10],
      [5, 3, 2, 6, 7, 8, 10, 9],
      [5, 3, 2, 6, 7, 8, 9, 10],
      [5, 6, 3, 7, 2, 8, 9, 10]
    ],
    answer: [5, 3, 2, 6, 7, 8, 9, 10],
    process: () => {},
    hint: "Preorder traversal: Visit root, left subtree, right subtree.",
  },
  {
    id: 9,
    text: "What is the postorder traversal of the binary search tree?",
    options: [
      [2, 3, 6, 8, 9, 10, 7, 5, 4],
      [2, 3, 6, 8, 9, 10, 7, 5],
      [2, 3, 6, 8, 10, 9, 7, 5],
      [2, 3, 6, 9, 8, 10, 7, 5]
    ],
    answer: [2, 3, 6, 8, 9, 10, 7, 5],
    process: () => {},
    hint: "Postorder traversal: Visit left subtree, right subtree, root.",
  },
  {
    id: 10,
    text: "Does the binary search tree contain the value 11?",
    options: [
      ["I don't know"], 
      ["Yes"],
      ["Maybe"],
      ["No"]
    ],
    answer: ["No"],
    process: () => {},
    hint: "Search for the value 7 in the binary search tree.",
  },
  {
    id: 11,
    text: "What is the inorder traversal of the binary search tree after deleting 3?",
    options: [
      [2, 5, 7, 8, 9, 10],
      [2, 3, 5, 6, 7, 8, 9, 10],
      [2, 5, 6, 7, 8, 9, 10],
      [2, 3, 5, 6, 7, 8]
    ],
    answer: [2, 5, 6, 7, 8, 9, 10],
    process: () => {
      bt.root = bt.deleteNode(bt.root, 3);
      displayedNumbers = bt.inorderTraversal(bt.root);
    },
    hint: "Delete 3 and check the new inorder traversal.",
  },
];

// Rooms for Heap Questions (12-15)
const heapRooms = [
  {
    id: 12,
    text: "What does the heap look like after heapifying the array [10, 4, 7, 2, 1]?",
    options: [
      [1, 2, 4, 7, 10],
      [10, 4, 7, 2, 1],
      [7, 4, 2, 10, 1],
      [10, 4, 2, 7, 1]
    ],
    answer: [10, 4, 7, 2, 1],
    process: () => {
      heap.heap = [10, 4, 7, 2, 1];
      heap._minHeapify(0);
    },
    hint: "Heapify the array and provide the resulting heap.",
  },
  {
    id: 13,
    text: "What is the heap after inserting 12?",
    options: [
      [10, 12, 4, 7, 2, 1],
      [12, 10, 4, 7, 2, 1],
      [7, 4, 2, 12, 10, 1],
      [10, 4, 12, 2, 7, 1]
    ],
    answer: [12, 10, 4, 7, 2, 1],
    process: () => {
      heap.insertHeap(12);
    },
    hint: "Insert 12 and observe the heap structure.",
  },
  {
    id: 14,
    text: "What does the min-heap look like with this array [15, 10, 20, 30, 5]?",
    options: [
      [5, 10, 15, 30, 20],
      [5, 10, 20, 15, 30],
      [10, 5, 20, 30, 15],
      [5, 15, 10, 20, 30]
    ],
    answer: [5, 10, 15, 30, 20],
    process: () => {
      heap.heap = [15, 10, 20, 30, 5];
      heap.buildMinHeap();
    },
    hint: "Construct a min-heap from the given values.",
  },
  {
    id: 15,
    text: "What does the max-heap look like with this array [15, 10, 20, 30, 5]?",
    options: [
      [30, 10, 15, 20, 5],
      [20, 30, 15, 10, 5],
      [30, 20, 15, 10, 5],
      [15, 20, 30, 10, 5]
    ],
    answer: [30, 20, 15, 10, 5],
    process: () => {
      heap.heap = [15, 10, 20, 30, 5];
      heap.buildMaxHeap();
    },
    hint: "Construct a max-heap from the given values.",
  }
];

// Game State
let currentRoom = 0;

// Start Game
function startGame() {
  showIntro();
}

// Show Intro and Tree Information
function showIntro() {
  textElement.innerText = `Welcome, adventurer! The initial numbers in the binary tree are: ${initialNumbers.join(
    ", "
  )}\n\nSolve the challenges in each room to escape!`;
  while (optionButtonsElement.firstChild) {
    optionButtonsElement.removeChild(optionButtonsElement.firstChild);
  }

  const button = document.createElement("button");
  button.innerText = "Start the Game";
  button.classList.add("btn");
  button.addEventListener("click", () => showRoom(0));
  optionButtonsElement.appendChild(button);
}

// Global Caps Lock Status
let capsLockOn = false;

// Caps Lock Prompt Function
function showCapsLockPrompt(toggleOn) {
  textElement.innerText = toggleOn
    ? "Please TURN ON Caps Lock and click Continue to proceed."
    : "Please TURN OFF Caps Lock and Control character to enter next room. TURN ON Caps Lock again and click Continue to proceed.";

  // Clear buttons
  while (optionButtonsElement.firstChild) {
    optionButtonsElement.removeChild(optionButtonsElement.firstChild);
  }

  const button = document.createElement("button");
  button.innerText = "Continue";
  button.classList.add("btn");
  button.addEventListener("click", () => {
    capsLockOn = toggleOn;
    showRoom(currentRoom); // Return to the next room question
  });
  optionButtonsElement.appendChild(button);
}
function showCapsLockPromptForQ12(toggleOn) {
  textElement.innerText = toggleOn
    ? "Please TURN OFF Caps Lock and Control character to enter next room. TURN ON Caps Lock again and click Continue to proceed."
    : "Please TURN ON Caps Lock and click Continue to proceed.";

  // Clear buttons
  while (optionButtonsElement.firstChild) {
    optionButtonsElement.removeChild(optionButtonsElement.firstChild);
  }

  const button = document.createElement("button");
  button.innerText = "Continue";
  button.classList.add("btn");
  button.addEventListener("click", () => {
    capsLockOn = toggleOn;
    showRoom(currentRoom); // Return to the next room question
  });
  optionButtonsElement.appendChild(button);
}
// Adjust `showRoom` to include Caps Lock logic
function showRoom(index) {
  if (index === 0 && !capsLockOn) return showCapsLockPrompt(true);  // Turn on Caps Lock for Q1-Q6
  if (index === 6 && capsLockOn) return showCapsLockPrompt(false); // Turn off Caps Lock before Q7
  if (index === 12 && !capsLockOn) return showCapsLockPromptForQ12(true); // Turn on Caps Lock for Q12

  let room;
  if (index < 12) {
    // Binary Tree Questions (1-11)
    room = binaryTreeRooms[index];
    const numbersText = `Current numbers in the binary tree: ${displayedNumbers.join(", ")}`;
    textElement.innerText = `${numbersText}\n\n${room.text}`;
  } else if (index >= 12 && index < 16) {
    // Heap Questions (12-15)
    room = heapRooms[index - 12]; // Adjust for heap room indexing
    const heapStateText = displayHeap();
    textElement.innerText = `${heapStateText}\n\n${room.text}`;
  } else {
    return showCongratulatoryMessage();
  }

  // Clear previous options and display new options
  while (optionButtonsElement.firstChild) {
    optionButtonsElement.removeChild(optionButtonsElement.firstChild);
  }
  
  room.options.forEach((option) => {
    const button = document.createElement("button");
    button.innerText = Array.isArray(option) ? option.join(", ") : option;
    button.classList.add("btn");
    button.addEventListener("click", () => checkRoomAnswer(index, option, room.answer));
    optionButtonsElement.appendChild(button);
  });
}

// After the last question
function checkRoomAnswer(index, selectedOption, correctAnswer) {
  if (JSON.stringify(selectedOption) === JSON.stringify(correctAnswer)) {
    
    const room = index < 12 ? binaryTreeRooms[index] : heapRooms[index - 12];
    if (room.process) room.process(); // Apply changes after correct answer
    currentRoom++;
    if (currentRoom < 16) {
      showRoom(currentRoom);
    } else {
      showCongratulatoryMessage();
    }
  } else {
    alert(`Incorrect! Hint: ${index < 12 ? binaryTreeRooms[index].hint : heapRooms[index - 12].hint}`);
  }
}

// Show Congratulatory Message
function showCongratulatoryMessage() {
  textElement.innerText = "Well done, brave soul! You've escaped the dungeon with skill and brilliance! You can now freely traverse the dungeon!";
  while (optionButtonsElement.firstChild) {
    optionButtonsElement.removeChild(optionButtonsElement.firstChild);
  }
}

// Start Game on Load
startGame();